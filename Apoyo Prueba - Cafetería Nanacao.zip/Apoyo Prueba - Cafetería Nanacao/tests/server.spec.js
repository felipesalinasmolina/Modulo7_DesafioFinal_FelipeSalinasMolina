const request = require("supertest");
const server = require("../index");

describe("Operaciones CRUD de cafes", () => {

});
